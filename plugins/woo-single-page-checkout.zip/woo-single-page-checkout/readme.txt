=== WooCommerce Single Page Checkout ===
Contributors: Brij Raj Singh
Tags:WooCommerce, Woocomerce Single Page Checkout,single page checkout,WooCommerce checkout,shop,products,one page checkout,affiliate, cart, checkout, commerce, configurable, digital, download, downloadable, e-commerce, ecommerce, inventory, reports, sales, sell, shipping, shop, shopping, stock, store, tax, variable, widgets, woothemes, wordpress ecommerce
Donate link: https://www.paypal.me/brijrajs
Requires at least: 3.9.1
Tested up to: 5.2.1
Stable tag: 1.2.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


Woocommerce Single Page Checkout , that shows checkout and cart in one page.

== Description ==

Woocommerce Single Page Checkout is an e-store extension that allows for faster checkout than ever before.
Woocommerce Single Page Checkout will allow users to complete the checkout process without spending time moving to a separate checkout page. 
After the user adds an item to their cart, the checkout fields and card of same page, allowing the user to complete the purchase process right then and there.
Advanced plugin settings allow to show your checkout page layout , you can show one Colum or two Colum for checkout fileds & card 


* You can choose one Colum or two Colum layout.
* You can choose to  manage your fields on your checkout.
* Shortcode [rg108_woocommerce_single_page_checkout]

*Credits*

Support Email: brijraj2011@gmail.com


== Installation ==

Install and Activate 

1. Unzip the downloaded 'woo-single-page-checkout' zip file
2. Upload the 'woo-single-page-checkout' folder and its contents into the `wp-content/plugins/` directory of your WordPress installation
3. Activate WooCommerce Single Page Checkout from Plugins page
4. Use shortcode [rg108_woocommerce_single_page_checkout] in your checkout page.

Implement

1. Go to the wp admin Settings >> Checkout Settings
2. you can show one Colum or two Colum for checkout fileds & card 

== Frequently Asked Questions ==

Q : How can I add a list of woo-single-page-checkout to my Project? A : Go to the Settings -> Checkout Settings -> you can choose one Colum or two Colum for checkout fileds & card.



== Screenshots ==

1. Admin interface & display .
