<?php
/**
Plugin Name:  WooCommerce Single Page Checkout
Description: Woocommerce One Page checkout.
Author: Brij Raj Singh
Text Domain: woo-single-page-checkout
Domain Path: /languages/
Version: 1.2.5
*/
if(!defined( 'ABSPATH' )) 
	exit;

require_once(dirname(__FILE__).'/includes/functions.php'); 
require_once(dirname(__FILE__).'/includes/setting.php'); 